import { SubmissionField } from './submission-field.model';

export class SubmissionForm {
    ID: number;
    Fields: SubmissionField[];
    Name: string;

    
}
